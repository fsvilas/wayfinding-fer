# Situm Wayfinding

Situm Wayfinding module written in Swift for iOS devices. This library allows users to position in a building, see its floors, see the building POIs (Point Of Interest), create routes to any point of the building, receive instructions to reach a place and more...

## Introduction

> Before starting to write code, we strongly recommend you to set up an account in our [Dashboard](https://dashboard.situm.es), retrieve your APIKEY and configure your first building. You can find a guide for this process [here] (http://developers.situm.es/pages/rest/authentication.html).

### Dependencies for development

1. MacOS.
2. Xcode. More about this IDE [here] (https://developer.apple.com/xcode/).
3. Cocoapods. Information about the installation process [here] (https://guides.cocoapods.org/using/getting-started.html).

### Configure wayfinding module

1. Download the framework [here]().
2. Drag and drop it in your project. Make sure to check the "Copy items if needed" option
3. Check under "Build Phases/Link binary with libraries" if `SitumWayfinding.framework` is present
4. Add a new "Copy Files" phase. Select Frameworks as destination and add the `SitumWayfinding.framework`
5. Under "Build Settings/Runpath Search Paths" add (if not already present) the path `@executable_path/Frameworks`
6. From now you can use any wayfinding service by using `import SitumWayfinding`

## Authenticate and load the wayfinding module

In order to use both SitumSDK and GoogleMaps capabilities you need to authenticate yourself.
This can be done by storing the credentials in a `KeysStore` that will later be forwarded to the `Facade` initializer.
You should also provide the `Facade` with both the `UIView` and the `UIViewController` that are gonna contain the wayfinding UI.
Finally, you just need to call the `load()` method. The following example illustrates this process:

```
let keyStore = KeysStore(withMail: "<DASHBOARD_MAIL>", situmKey: "<DASHBOARD_API_KEY>", googleKey: "<GOOGLEMAPS_API_KEY>")
let facade = Facade(withCredentials: keyStore, containedBy: containerView, controlledBy: containerViewController)
facade.load()
```
